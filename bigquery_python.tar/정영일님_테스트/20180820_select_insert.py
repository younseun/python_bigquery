
# coding: utf-8

# In[45]:



from google.cloud import bigquery
from datetime import timedelta
from datetime import datetime
import argparse
import time
import sys, os
from time import sleep


# In[63]:


def query_execute(project, destination_schema, destination_table, date_key, query_string):
    client = bigquery.Client(project=project)
    job_config = bigquery.QueryJobConfig()

    dataset_id=destination_schema
    table_id = destination_table+'${{partition_yyyymmdd}}'
    table_id = table_id.replace('{{partition_yyyymmdd}}', str(date_key.replace('-','')))
    table_ref = client.dataset(dataset_id).table(table_id)
    job_config.destination = table_ref
    job_config.write_disposition = 'WRITE_TRUNCATE'
    query_job = client.query(query_string, job_config=job_config)
    print('destination          :', table_ref)
    results = query_job.result()  


# In[76]:


def replace_sql(root_path, date_key):
    sql_filename = root_path+'/sql/login_test.sql'
    sql_log_filename = root_path + '/sql/login_test_'+str(date_key.replace('-',''))+'.sql'
    print('Src Filename         : {}'.format(sql_filename))
    print('Log Filename         : {}'.format(sql_log_filename))
    query_string = ''
    with open(sql_filename, 'r') as file:
        sql = file.read()
        query_string = sql.replace('{{date_key}}', str(date_key))
    with open(sql_log_filename, 'w') as file:
        file.write(query_string)
        file.close()
    print('Query_String         :', query_string)
    return query_string


# In[77]:


def main(meta_tuple):
    global project
    global date_key
    global destination_schema
    global destination_table

    root_path = '/home/younseun/test'
    
    # Input Parameter
    project = meta_tuple[0]
    date_key = meta_tuple[1]
    destination_schema = meta_tuple[2]
    destination_table = meta_tuple[3]
    
    #print('>>>',project,date_key,destination_schema, destination_table)    
    
    query_string = replace_sql(root_path, date_key)
    query_execute(project, destination_schema, destination_table, date_key, query_string)
    
    result = 'success'
    return result


# In[78]:


def parse_parameters():
    #     print('\nprocessing parse_parameters() ...')

    #################################################
    # 개발 완료되면 풀어야 함. !!!!!!!!!!!!!!!!!!!
    #################################################
    parser = argparse.ArgumentParser(description='시스템 구동에 필요한 파라미터를 입력하세요.')
    parser.add_argument("--project", help="프로젝트명을 입력하세요.반드시 입력해야 하는 값입니다.", required=True)
    parser.add_argument("--date_key", help="배치작업 기준일자를 YYYY-MM-DD 형태로 입력하세요. 반드시 입력해야 하는 값입니다.", required=True)
    parser.add_argument("--destination_schema", help="저장될 DataSet을 입력하세요. 반드시 입력해야 하는 값입니다.", required=True)
    parser.add_argument("--destination_table", help="저장될 TableName을 입력하세요. 반드시 입력해야 하는 값입니다.", required=True)
    args = parser.parse_args()

    project = args.project
    date_key = args.date_key
    destination_schema = args.destination_schema
    destination_table = args.destination_table

    #################################################
    # 개발 완료되면 막아야 함. !!!!!!!!!!!!!!!!!!!
    #     project = 'miinfra-project'
    #     date_key = '2018-05-10'
    #     destination_schema = 'temp'
    #     destination_table = 'aaaa'
    #################################################

    try:
        if len(date_key.split('-')) != 3:
            raise ValueError('\'date\' parameter seems wrong. It must be in \'YYYY-MM-DD\' format.')
    except ValueError:
        raise

    print('[Start] {}'.format(datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))        
    print('- Input parameter : --project = {}'.format(project))
    print('- Input parameter : --date_key = {}'.format(date_key))
    print('- Input parameter : --destination_schema = {}'.format(destination_schema))
    print('- Input parameter : --destination_table = {}'.format(destination_table))


    return project, date_key, destination_schema, destination_table


# In[79]:


if __name__ == '__main__':
    start_time = time.time()
    result = 0
    #python3 /home/younseun/bigquery_python/20180820_select_insert.py --date_key 2018-06-13 --project miinfra-project --destination_schema temp --destination_table aaaa
    #result = main(['miinfra-project','2018-06-15','temp','aaaa'])
    result = main(parse_parameters())


