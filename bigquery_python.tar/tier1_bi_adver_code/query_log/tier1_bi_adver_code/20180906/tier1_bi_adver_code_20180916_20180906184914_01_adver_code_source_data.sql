    
Select gamecode, LogDetailID, CampaignName, ChannelName, ADName, Min(regdatetime) regdatetime
  From (Select gamecode, LogDetailID, CampaignName, ChannelName, ADName, Min(regdatetime) regdatetime
        From (
              Select Upper(gamecode) as gamecode, Case When LogDetailID in (1,3) Then 1 When LogDetailID in (2,4) Then 2 Else 0 End LogDetailID,
                  IFNULL(Upper(Case When LogID=105 And Upper(publisher_name) = Upper('nanigans') Then Upper('Twitter')
                                    When LogID=105 And Upper(publisher_name) = Upper('Ironsource') Then Upper('Supersonic')
                                    When LogID=105 Then Upper(publisher_name)
                                    When LogID=7777 Then Upper('ORGANIC')
                                     When LogID=106 Then Case When Upper(network_name) Like '%FACEBOOK%' OR Upper(network_name) Like '%INSTAGRAM%'
                                                                                     Then Upper('FACEBOOK') Else Upper(network_name) End End),'ORGANIC') as CampaignName,
                  IFNULL(Upper(Case When LogID=105 And Upper(publisher_name) = Upper('Twitter') Then publisher_sub_campaign_name
                            When LogID=105 And Upper(publisher_name) = Upper('Adcolony performance media') then sub_site    -- 20170220 추가
                            When LogID=105 And Upper(publisher_name) = Upper('Apple Search Ads')     Then publisher_sub_adgroup_name                 -- 20180426 추가
                            When LogID=105 And Upper(publisher_name) = Upper('nanigans') Then publisher_sub_campaign_name
                            When LogID=105 And Upper(publisher_name) = Upper('LoopMe') Then my_site
                            When LogID=105 And Upper(publisher_name) = Upper('unity ads') Then sub_site
                            When LogID=105 And Upper(publisher_name) = Upper('Google Adwords') Then sub_campaign
                            When LogID=105 And Upper(publisher_name) = Upper('Adscreen')       Then sub_publisher
                            When LogID=105 And Upper(publisher_name) = Upper('Cheetah Mobile') Then publisher_sub_site
                            When LogID=105 And Upper(publisher_name) = Upper('Cashslide_NCPI') Then publisher_sub1
                            When LogID=105 And Upper(publisher_name) = Upper('Cashslide')      Then publisher_sub1
                            When LogID=105 And Upper(publisher_name) = Upper('Glispa')         Then sub_site
                            When LogID=105 And Upper(publisher_name) = Upper('Tapjoy')         Then Publisher_sub_site
                            When LogID=105 And Upper(publisher_name) = Upper('Vungle')         Then Publisher_sub_site
                            When LogID=105 And Upper(publisher_name) = Upper('Chartboost' )    Then publisher_sub_site_name
                            When LogID=105 And Upper(publisher_name) = Upper('Fyber formerly SponsorPay')     Then sub_site
                            When LogID=105 And Upper(publisher_name) = Upper('Adcolony')       Then Concat(sub_publisher,'>',publisher_sub_site_name)
                            When LogID=105 And Upper(publisher_name) = Upper('The Trade Desk') Then my_adgroup
                            When LogID=105 And Upper(publisher_name) = Upper('CrossInstall')     Then sub_site
                            When LogID=105 And Upper(publisher_name) = Upper('Snapchat')     Then publisher_sub_campaign_name
                            When LogID=105 Then sub_publisher
                            When LogID=106 And Upper(network_name) = Upper('apple search ads') Then site_id
                            When LogID=106 Then campaign_name
                            When LogID=7777 Then ADSet_Name End),'ORGANIC') as ChannelName,
                  IFNULL(Upper(Case When LogID=105 And Upper(publisher_name) = Upper('Twitter')  Then sub_site
                                      When LogID=105 And Upper(publisher_name) = Upper('nanigans')  Then sub_site
                                      When LogID=105 And Upper(publisher_name) = Upper('Apple Search Ads')  Then publisher_sub_keyword_name 
                                      When LogID=105 And Upper(publisher_name) = Upper('chartboost') Then publisher_sub_campaign_name
                                      When LogID=105 And Upper(publisher_name) = Upper('mobvista') Then publisher_sub_campaign_name
                                      When LogID=105 And Upper(publisher_name) = Upper('unity ads') Then publisher_sub_campaign_name
                                      When LogID=105 And Upper(publisher_name) = Upper('vungle') Then publisher_sub_campaign_name
                                      When LogID=105 And Upper(publisher_name) = Upper('adscreen') Then  '' 
                            When LogID=105 And Upper(publisher_name) = Upper('Google Adwords') Then sub_site
                            When LogID=105 Then my_campaign
                            When LogID=106 Then adgroup_name
                            When LogID=7777 Then Upper(AD_Name) End),'ORGANIC') as ADName,
                   Min(Timestamp(regdatetime)) as regdatetime
              From Tier0_BI.Log_GlobalAd_20180916 a 
                -- 2018-06-04 변경
                -- Where ((LogID IN (105,7777) And (publisher_name not in ('Instagram','facebook','nanigans - facebook','Adquant - Facebook','Facebook - Adquant','cyberz - facebook','cyberz - instagram') or publisher_name is null ))   -- is null : Organic도 잡아야 하기 때문
                --        OR (LogID = 106 And network_name IN ('Facebook','Instagram','nanigans - facebook','Adquant - Facebook','Facebook - Adquant','cyberz - facebook','cyberz - instagram')))    -- Apple Search Ads 삭제 : 2018-04-26
                Where ((a.LogID IN (105,7777) And (((Upper(publisher_name) not like '%FACEBOOK%') And (Upper(publisher_name) not like '%INSTAGRAM%')) or publisher_name is null ))
                                        OR (a.LogID = 106 And ((Upper(a.network_name) Like '%FACEBOOK%') OR (Upper(a.network_name) Like '%INSTAGRAM%'))))
                  And LogDetailID IN (1,2,3,4)
                  And (replay is Null OR replay = '')       -- 재전송인경우 영향을 받지 않기 위해서 추가(20180502)
              Group By gamecode, LogDetailID, CampaignName, ChannelName, ADName     ) Last
          Group By gamecode, LogDetailID, CampaignName, ChannelName, ADName
          Union All
          Select Upper(SchemaNM), b.LogDetailID, Upper('Organic'), Upper('Organic'), Upper('Organic'),  timestamp_trunc(Timestamp_Add(CURRENT_TIMESTAMP(), Interval 9 Hour),second)
            From Tier1_BI.code_dim_gamelist a 
              Cross Join (Select 1 as LogDetailID Union All Select 2) b
              ) c
      Group By gamecode, LogDetailID, CampaignName, ChannelName, ADName
                  
                  