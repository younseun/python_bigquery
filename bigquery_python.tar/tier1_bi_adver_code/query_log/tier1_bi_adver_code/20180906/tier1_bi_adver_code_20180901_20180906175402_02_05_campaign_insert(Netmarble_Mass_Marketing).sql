Insert Into Tier1_BI.code_info_campaign_ver3_develop
    (CampaignID, CampaignName, AppID, Status, Status_codekind, MediaType, MediaType_codekind, AdvertiseType, AdvertiseType_codekind, 
     TrafficType, TrafficType_codekind, StartDate, EndDate, TotalBudget, currency, currency_codekind, redirectUrl, webview_info, ExtractDT)
Select 2006059 + Row_Number() Over (Order By GameKey) as CampaignID, 
       Upper('Netmarble Mass Marketing') as CampaignName, a.AppID,
       '01' as Status, '0006' as Status_codekind, 
       '1' as mediaType, '0017' as mediatype_codekind,
       '01' as AdvertiseType, '0004' as AdvertiseType_codekind,
       '07' as TrafficType, '0005' as TrafficType_codekind,
       Timestamp('2018-09-01') as StartDate, Timestamp('2050-01-01') as EndDate,
       0.0 as TotalBudget, '04' as currency, '0007' as currency_codename, '' as redirectURL,
       '0000000000' as webview_info, timestamp_trunc(Timestamp_Add(CURRENT_TIMESTAMP(), Interval 9 Hour),second) ExtractDT
  From Tier1_BI.code_info_app_ver3_develop a
       Left Outer Join Tier1_BI.code_info_campaign_ver3_develop b
            ON a.AppID = b.AppID And Upper(b.CampaignName) = Upper('Netmarble Mass Marketing')
 Where b.AppID IS NULL
    