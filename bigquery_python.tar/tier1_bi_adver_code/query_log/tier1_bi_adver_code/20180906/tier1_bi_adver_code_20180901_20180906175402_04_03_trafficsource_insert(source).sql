Insert Into Tier1_BI.code_info_trafficsource_ver3_develop
    (TrafficSourceID, CampaignID, ChannelID, Status, Status_codekind, TotalBudget, SpentBudget, Price, 
     currency, currency_codekind, PricingType, PricingType_codekind, AppID, webview_info, ExtractDT)
Select 2682175 + Row_Number() Over (Order By T.CampaignID, U.ChannelID) as TrafficSourceID, 
       T.CampaignID, U.ChannelID, 
       '01' as Status, '0010' as Status_codekind, 
       0 as TotalBudget, 0 as SpentBudget, 0 as Price,
       '01' as currency, '0007' as currency_codekind,
       '99' as PricingType, '0011' as PricingType_codekind,
       T.AppID, '0000000000' as webview, timestamp_trunc(Timestamp_Add(CURRENT_TIMESTAMP(), Interval 9 Hour),second) ExtractDT
  From temp.tier1_bi_adver_code_20180901_20180906175402_trafficsource S
       Inner Join (Select CampaignID, MediaType, a.CampaignName, a.appid, b.market, 
                               Case When Upper(c.schemaNM)=Upper('chacha') Then Upper('chachacha')
                                    When Upper(c.schemaNM)=Upper('pongpong') Then Upper('everypong') Else Upper(c.schemaNM) End as Gamecode
                          From Tier1_BI.code_info_campaign_ver3_develop a 
                               Inner Join Tier1_BI.code_info_app_ver3_develop b  On a.appid = b.appid
                               Inner Join Tier1_BI.code_dim_gamelist c On Cast(b.gamekey as INT64) = c.gamekey
                         Where a.CampaignID > 1000000) T On Upper(S.CampaignName) = Upper(T.CampaignName)
            And S.gamecode = T.Gamecode And Case When S.LogDetailID = 1 Then '01' Else '02' End = T.market 
       Inner Join Tier1_BI.code_info_channel_ver3_develop U ON Upper(S.ChannelName) = Upper(U.ChannelName) 
                  And U.ChannelID > 1000000
       Left Outer Join Tier1_BI.code_info_trafficsource_ver3_develop V ON T.CampaignID = V.CampaignID
                  And U.ChannelID = V.ChannelID 
                  And V.CampaignID > 1000000
                  And V.ChannelID > 1000000
                  And V.TrafficSourceID > 1000000
 Where V.TrafficSourceID IS NULL
    