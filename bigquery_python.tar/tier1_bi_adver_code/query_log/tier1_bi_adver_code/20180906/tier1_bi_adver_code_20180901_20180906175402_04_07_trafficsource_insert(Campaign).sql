Insert Into Tier1_BI.code_info_trafficsource_ver3_develop
    (TrafficSourceID, CampaignID, ChannelID, Status, Status_codekind, TotalBudget, SpentBudget, Price, 
     currency, currency_codekind, PricingType, PricingType_codekind, AppID, webview_info, ExtractDT)
Select 2682175 + Row_Number() Over (Order By AA.AppID, AA.CampaignID, AA.ChannelID) as TrafficSourceID, 
       AA.CampaignID, AA.channelID, 
       '01' as Status,'0010' as Status_codekind, 0 as totalBudget, 0 as SpentBudget, 0 as Price, 
       '04' as currency, '0007' as currency_codekind, '99' as PricingType, '0011' as PricingType_codekind, 
       AA.AppID, '' webview_info, timestamp_trunc(Timestamp_Add(CURRENT_TIMESTAMP(), Interval 9 Hour),second) ExtractDT
  From (
        Select a.AppID, a.CampaignID, b.ChannelID
          From Tier1_BI.code_info_campaign_ver3_develop a
               Inner Join Tier1_BI.code_info_channel_ver3_develop b
                     ON Upper(b.ChannelName) = '공통'
         Where Mediatype in ('105','7777') ) AA
       Left Outer Join Tier1_BI.code_info_trafficsource_ver3_develop BB
            ON AA.AppID = BB.appID And AA.CampaignID = BB.CampaignID And AA.ChannelID = BB.ChannelID
 Where BB.AppID IS NULL

 
    