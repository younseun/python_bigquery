Select gamecode, LogDetailID, CampaignName, Min(Regdatetime) as Regdatetime
  From temp.tier1_bi_adver_code_20180901_20180906175402_01_adver_code_source_data
 Group By gamecode, LogDetailID, CampaignName
 