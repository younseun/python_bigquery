Insert Into Tier1_BI.code_info_ad_ver3_develop
    (ADID, AppID, CampaignID, ChannelID, Location, Status, Status_codekind, ADType, ADType_codekind, View_Order, 
     TotalBudget, SpentBudget, Price, webview_info, ExtractDT, trafficsourceid, Tracking_Link)
Select 4301940 + Row_Number() Over (Order By a.TrafficsourceID) as ADID, 
       a.AppID, a.CampaignID, a.ChannelID, c.ChannelName Location,
       '01' Status,'0015' Status_codekind, '99' as ADType, '0016' as ADType_codekind,
       1 as View_Order, 0 TotalBudget, 0 as SpentBudget, 0 as Price, '' as webview_info,
       timestamp_trunc(Timestamp_Add(CURRENT_TIMESTAMP(), Interval 9 Hour),second) ExtractDT, a.TrafficSourceID, Tracking_Link
  From Tier1_BI.code_info_trafficsource_ver3_develop a
       Inner Join Tier1_BI.code_info_campaign_ver3_develop b
             ON a.campaignID = b.campaignID 
       Inner Join Tier1_BI.code_info_channel_ver3_develop c
             ON a.ChannelID = c.ChannelID And c.ChannelName = '공통'
       Left Join Tier1_BI.code_info_ad_ver3_develop d
            ON a.AppID = d.AppID and a.CampaignID = d.CampaignID And a.ChannelID = d.ChannelID And a.TrafficSourceID = d.trafficsourceid
            And Upper(d.Location) = Upper(c.ChannelName)
 Where d.AppID IS NULL

 
    