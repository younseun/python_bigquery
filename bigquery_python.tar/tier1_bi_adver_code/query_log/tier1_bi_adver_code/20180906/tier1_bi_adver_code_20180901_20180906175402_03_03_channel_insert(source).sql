Insert Into Tier1_BI.code_info_channel_ver3_develop
    (ChannelID, ChannelName, ChannelType, ChannelType_codekind, Status, Status_codekind, PricingTypeArray, Adver_AppID, ExtractDT)
    Select 2507075 + Row_Number() Over (Order By a.ChannelName) as ChannelID, 
           a.ChannelName, 
           '03' as ChannelType, '0008' as ChannelType_codekind, 
           '01' as Status, '0009' as Status_codekind, 
           '' as PricingTypeArray, 0 as Adver_AppID, timestamp_trunc(Timestamp_Add(CURRENT_TIMESTAMP(), Interval 9 Hour),second) ExtractDT
      From temp.tier1_bi_adver_code_20180901_20180906175402_channel a
           Left Outer Join Tier1_BI.code_info_channel_ver3_develop b On Upper(a.ChannelName) = Upper(b.ChannelName)
                And ChannelID > 1000000
     Where b.ChannelID IS NULL
    