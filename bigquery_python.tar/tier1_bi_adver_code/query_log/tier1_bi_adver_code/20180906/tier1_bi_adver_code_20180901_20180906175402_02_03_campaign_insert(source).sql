Insert Into Tier1_BI.code_info_campaign_ver3_develop
    (CampaignID, CampaignName, AppID, Status, Status_codekind, MediaType, MediaType_codekind, AdvertiseType, AdvertiseType_codekind, 
     TrafficType, TrafficType_codekind, StartDate, EndDate, TotalBudget, currency, currency_codekind, redirectUrl, webview_info, ExtractDT)
    Select 2006059 + Row_Number() Over (Order By c.RegDatetime) as CampaignID, 
       Upper(c.CampaignName) CampaignName, App.AppID, 
       '01' as Status, '0006' as Status_codekind, 
       '105' as MediaType, '0017' as MediaType_codekind,
       '01' as AdvertiseType, '0004' as AdvertiseType_codekind, 
       '06' as TrafficType, '0005' as TrafficType_codekind,
       Timestamp('2018-09-01') as StartDate, Timestamp('2050-01-01') as EndDate,
       0.0 as TotalBudget, '01' as currency, '0007' as currency_codekind, '' as redirectUrl, 
       '0000000000' as webview_info, timestamp_trunc(Timestamp_Add(CURRENT_TIMESTAMP(), Interval 9 Hour),second) ExtractDT
  From Tier1_BI.code_info_app_ver3_develop App
       Inner Join Tier1_BI.code_dim_gamelist b ON Cast(App.gamekey as INT64) = b.gamekey
       Inner Join temp.tier1_bi_adver_code_20180901_20180906175402_campaign c 
              ON Case When Upper(b.schemaNM)=Upper('chacha') Then Upper('chachacha')
                      When Upper(b.schemaNM)=Upper('pongpong') Then Upper('everypong') Else Upper(b.schemaNM) End = Upper(c.gamecode) 
              And App.market = Case When LogDetailid = 1 Then '01' Else '02' End
       Left outer Join Tier1_BI.code_info_campaign_ver3_develop Campaign ON App.AppID = Campaign.AppID And Upper(Campaign.CampaignName) = Upper(c.CampaignName)
 Where Campaign.AppID IS NULL
    