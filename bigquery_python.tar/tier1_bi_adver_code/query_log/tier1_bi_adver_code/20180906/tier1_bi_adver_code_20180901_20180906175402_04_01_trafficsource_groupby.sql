Select LogDetailID, gamecode, CampaignName, ChannelName
  From temp.tier1_bi_adver_code_20180901_20180906175402_01_adver_code_source_data
 Group By LogDetailID, gamecode, CampaignName, ChannelName
 