Insert Into Tier1_BI.code_info_ad_ver3_develop
    (ADID, AppID, CampaignID, ChannelID, Location, Status, Status_codekind, ADType, ADType_codekind, View_Order, 
     TotalBudget, SpentBudget, Price, webview_info, ExtractDT, trafficsourceid, Tracking_Link)
Select 4301940 + Row_Number() Over (Order By a.CampaignID) as ADID, 
       a.AppID, a.CampaignID, a.ChannelID, f.ADName Location,
       '01' as Status, '0015' as Status_codekind,
       '99' as ADType, '0016' as ADType_codekind,
       1 as View_Order, 0 as TotalBudget, 0 as SpentBudget, 0 as price,
       '0000000000' as webview, timestamp_trunc(Timestamp_Add(CURRENT_TIMESTAMP(), Interval 9 Hour),second) ExtractDT, a.TrafficSourceID, '' as Tracking_Link
  From Tier1_BI.code_info_trafficsource_ver3_develop a
       Inner Join Tier1_BI.code_info_channel_ver3_develop b On a.channelID = b.ChannelID
       Inner Join Tier1_BI.code_info_app_ver3_develop c On a.Appid = c.appid
       Inner Join Tier1_BI.code_dim_gamelist d on Cast(c.gamekey as INT64) = d.gamekey
       Inner Join Tier1_BI.code_info_campaign_ver3_develop e On a.CampaignID = e.CampaignID
       Inner Join temp.tier1_bi_adver_code_20180901_20180906175402_01_adver_code_source_data f On Upper(e.CampaignName) = Upper(f.CampaignName)
             And Upper(d.schemaNM) = Upper(f.gamecode) And Upper(b.ChannelName) = Upper(f.ChannelName)
             And Case When f.LogDetailID = 1 Then '01' Else '02' End = c.market
       Left Join Tier1_BI.code_info_ad_ver3_develop g On a.AppID = g.AppID
            And a.CampaignID = g.CampaignID And a.ChannelID = g.ChannelID And a.TrafficSourceID = g.trafficsourceid
            And Upper(f.ADName) = Upper(g.Location)
            And g.ADID > 1000000 
 Where a.TrafficSourceID > 1000000 
   And g.AppID IS NULL
 order by 1,2,3

 
    