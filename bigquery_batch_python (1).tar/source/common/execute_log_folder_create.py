
# coding: utf-8

# In[8]:


#-*- coding: utf-8 -*-
from datetime import timedelta

from datetime import datetime
import argparse
import time
import sys, os


# In[ ]:



# Real배포시 수정사항
# 1. os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="/home/mi_admin/miinfra-project-90dbee12067b.json"
# 2. parse_parameters(): 안에 막는부분과 푸는 부분


os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="/home/mi_admin/miinfra-project-90dbee12067b.json"


# In[ ]:



def log_folder_create(root_path, date_key):
    if not os.path.exists(root_path+'/execute_log/'+batch_yyyymmdd):
        os.makedirs(root_path+'/execute_log/'+batch_yyyymmdd)


# In[ ]:



def main(meta_tuple):
    global date_key
    global batch_datetime
    global unique_id

    # Input Parameter
    date_key = meta_tuple[0]
    batch_datetime = meta_tuple[1]
    unique_id = meta_tuple[2]

    # Information Data
    global root_path
    global category
    global package_name
    root_path = "/home/mi_admin/bigquery_batch_python"
    category = "sensor"
    package_name = 'execute_log_folder_create'

    # Variable
    global batch_yyyymmdd
    batch_yyyymmdd = batch_datetime[0:8]

    ###############################################################################################

    #Log Folder Create
    log_folder_create(root_path, batch_yyyymmdd)

    ###############################################################################################
    # 아래 로그를 남기는 것은 각 스텝별로 적용되어야 한다.
    # 로그파일과 renderer파일을 각각 남긴다.
    # 로그폴더를 남기는 python코드라서 어쩔수 없이 아래쪽에 기술하였음.
    # Package Log Start
    # Package Log End
    f = open("/home/mi_admin/bigquery_batch_python/execute_log/"+batch_yyyymmdd+"/"+ batch_datetime+"_"+unique_id+"_"+date_key.replace("-", "")+"_"+category+"_"+package_name+"_01.log", 'w')
    f.write("["+batch_datetime+"_"+category+"_"+package_name+"_"+unique_id+"] Log Start - "+datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")+"\n")
    f.write(root_path+'/execute_log/'+batch_yyyymmdd+"\n")
    f.write("["+batch_datetime+"_"+category+"_"+package_name+"_"+unique_id+"] Log End - "+datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")+"\n")
    f.close()

    return package_name


# In[ ]:



def parse_parameters():
    #     print('\nprocessing parse_parameters() ...')

    #################################################
    # 개발 완료되면 풀어야 함. !!!!!!!!!!!!!!!!!!!
    #################################################
    parser = argparse.ArgumentParser(description='시스템 구동에 필요한 파라미터를 입력하세요.')
    parser.add_argument("--date_key", help="배치작업 기준일자를 YYYY-MM-DD 형태로 입력하세요. 반드시 입력해야 하는 값입니다.", required=True)
    parser.add_argument("--batch_datetime", help="배치실행일자를 YYYYMMDDHH24MISS 형태로 입력하세요. 반드시 입력해야 하는 값입니다.", required=True)
    parser.add_argument("--unique_id", help="배치 Unique_id를 입력하세요. 반드시 입력해야 하는 값입니다.", required=True)
    args = parser.parse_args()

    date_key = args.date_key
    batch_datetime = args.batch_datetime
    unique_id = args.unique_id

    #################################################
    # 개발 완료되면 막아야 함. !!!!!!!!!!!!!!!!!!!
    #date_key = '2018-05-10'
    #batch_datetime = '20180531123456'
    #unique_id = 'unique_id'
    #################################################


    try:
        if len(date_key.split('-')) != 3:
            raise ValueError('\'date\' parameter seems wrong. It must be in \'YYYY-MM-DD\' format.')
    except ValueError:
        raise

    print('- Input parameter : --date_key = {}'.format(date_key))
    print('- Input parameter : --batch_datetime = {}'.format(batch_datetime))
    print('- Input parameter : --unique_id = {}'.format(unique_id))

    return date_key, batch_datetime, unique_id


# In[ ]:


if __name__ == '__main__':
    start_time = time.time()
    #python3 /home/younseun/bigquery_batch_python/bigquery_batch_python/source/common/execute_log_folder_create.py --date_key 2018-06-13 --batch_datetime 20180614_123456 --unique_id abcdefghij
    #package_name = main(['2018-06-13','20180614_123456','abcdefg'])
    package_name = main(parse_parameters())
    print('[Complete] {} total elapsed : {} seconds'.format(package_name, time.time()-start_time))

